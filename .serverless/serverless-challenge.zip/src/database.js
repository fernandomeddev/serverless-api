"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prismaDatabase = void 0;
var client_1 = require("@prisma/client");
var prismaDatabase = new client_1.PrismaClient({});
exports.prismaDatabase = prismaDatabase;
//# sourceMappingURL=database.js.map